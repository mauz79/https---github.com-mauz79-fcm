// fcmAlbumVariabili.js
// File Css 0=Classico 1=Maelstrom Mix
var lcsTipoCss="1";
// Gestione Divisione S=si N=no
var lcsGestioneDivisioni="S";
// Tipo Gestione Divisione 1=Per Squadra Selezionata 2=Tutti
var lcsTipoGestioneDivisioni="1";
// Anno Primo Contratto: Se=0 non elabora
var lcsAnnoPrimoContratto=0;
